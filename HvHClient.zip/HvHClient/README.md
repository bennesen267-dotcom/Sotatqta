# HvHClient

Minecraft 1.20.1 Fabric client mod. Menu key: **N**.

## Modules
- **AutoInventoryTotem**: Enabled, Auto Open, Auto Close, Hover, Health, Totem Slot, Delay
- **SelfDestruct**: deletes the config and mod jar after confirmation

## AutoInventoryTotem
- Health is based on `getHealth()` only (absorption hearts are not counted).
- Auto Open: opens the inventory and equips a totem when health is low.
- Auto Close: closes the inventory after equipping.
- Even with Auto Open/Close off, an open inventory equips a totem when health is low.
- Hover: when enabled, an open inventory also refills the Totem Slot automatically.
- Delay: ticks between actions (20 ticks = 1 second).

## Build
Requires Java 17. Add the Gradle wrapper first (`gradle wrapper --gradle-version 8.5`), then:

    ./gradlew build

The jar is in `build/libs/`.
